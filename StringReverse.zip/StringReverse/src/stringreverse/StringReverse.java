/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringreverse;

/**
 *
 * @author user
 */
public class StringReverse {
    public String reverse (String s){
        String reversedString = "";
        for (int i =s.length(); i>0; i--){
            reversedString += s.charAt(i-1);
        }
        return reversedString;
    }
}
